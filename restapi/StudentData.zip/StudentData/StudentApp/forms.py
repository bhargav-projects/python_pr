from django import forms


from StudentApp.models import StudentModel

class StudentForm(forms.ModelForm):
    class Meta:
        model = StudentModel
        fields ='__all__'
        
class StudentForm2(forms.ModelForm):
    class Meta:
        model = StudentModel
        fields =['Roll_Number',]

